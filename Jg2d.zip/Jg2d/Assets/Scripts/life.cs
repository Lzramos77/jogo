public class Life : NetworkBehaviour 
{  
    public const int maxLife = 100;
    [SyncVar (hook="OnChangeLife" )]
    public int life = maxLife;
    public RectTransform lifeBar;
    public void Damage( int damage)
    {

     if (lisServer)
        return;

     life -= damage;
     if (life <= 0) 
      {
        life = maxLife;
        {
        RpcRespawn();
        }
      }
    }
 void OnChangeLife(int life)
    {
    lifeBar.sizeDelta = new Vector2(life, lifeBar.sizeDelta.y);
    }

    [ClientRpc]
  void RpcRespawn()
    {
     if (isLocalPlayer)
        {
        transform.position = Vector.zero; 
        }
    } 
}
