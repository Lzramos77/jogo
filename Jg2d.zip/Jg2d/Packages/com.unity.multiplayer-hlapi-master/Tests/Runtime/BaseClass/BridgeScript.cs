﻿using UnityEngine;

public class BridgeScript : MonoBehaviour
{
    public const string bridgeGameObjectName = "UnetBridgeGO_SetupBase";

    public GameObject playerPrefab;
    public GameObject rocketPrefab;
}
